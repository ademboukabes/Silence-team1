class AppImagePath {
  static String kLogoListenLit = 'assets/images/ListenLitlogoSplash.svg';
  static String kOnboarding1 = 'assets/images/Onboarding1.svg';
  static String kOnboarding2 = 'assets/images/Onboarding2.svg';
  static String kOnboarding3 = 'assets/images/OnBoarding3.svg';
  static String kRectangleBackgound = 'assets/images/Background.png';
  static String kLogoFacebook = 'assets/images/logo_facebook.svg';
  static String kGoogleLogo = 'assets/images/googleLogo.svg';
  static String kApple = 'assets/images/Apple.svg';
  static String kSuccessIcon = 'assets/images/successIcon.svg';
  static String kProfile = 'assets/images/profile.png';
  static String kRoyryanMercStory = 'assets/images/RoyryanMerc.png';
  static String kNeilGaimanStory = 'assets/images/NeilGaiman.png';
  static String kMarkmcallisterpngStory = 'assets/images/Markmcallisterpng.png';
  static String kMichaelDougStory = 'assets/images/MichaelDoug.png';
  static String kCardBackground = 'assets/images/CardBackground.png';
  static String kcreative = 'assets/images/creative.png';
  static String kFuturism = 'assets/images/Futurism.png';
  static String kNorsemythology = 'assets/images/Norsemythology.png';
  static String kThegoodguy = 'assets/images/thegoodguy.png';
  static String kSuccessPremiumAccess =
      'assets/images/successPremiumAccess.svg';
  static String kFuturamaBigPic = 'assets/images/FuturamaBigPic.png';
}
