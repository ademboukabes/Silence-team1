import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:listenlit/controllers/booking_controller.dart';
import 'package:listenlit/pages/booking/reserve_step2_screen.dart';

class ReserveStep1Screen extends StatefulWidget {
  const ReserveStep1Screen({super.key});

  @override
  State<ReserveStep1Screen> createState() => _ReserveStep1ScreenState();
}

class _ReserveStep1ScreenState extends State<ReserveStep1Screen> {
  final BookingController controller = Get.find<BookingController>();

  late TextEditingController _containerCtrl;
  late TextEditingController _nameCtrl;
  late TextEditingController _phoneCtrl;
  late TextEditingController _plateCtrl;

  @override
  void initState() {
    super.initState();
    _containerCtrl = TextEditingController(text: controller.containerId.value);
    _nameCtrl = TextEditingController(text: controller.driverName.value);
    _phoneCtrl = TextEditingController(text: controller.driverPhone.value);
    _plateCtrl = TextEditingController(text: controller.truckPlate.value);

    controller.loadInit();
  }

  @override
  void dispose() {
    _containerCtrl.dispose();
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    _plateCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0B1F35),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0F2942),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            color: Colors.white,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Nouvelle Réservation',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18.sp,
                fontWeight: FontWeight.w600,
              ),
            ),
            Text(
              'Étape 1 sur 2',
              style: TextStyle(
                color: Colors.white60,
                fontSize: 12.sp,
                fontWeight: FontWeight.w400,
              ),
            ),
          ],
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(6),
          child: Container(
            height: 6.h,
            margin: EdgeInsets.symmetric(horizontal: 16.w),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.1),
              borderRadius: BorderRadius.circular(3),
            ),
            child: FractionallySizedBox(
              alignment: Alignment.centerLeft,
              widthFactor: 0.5,
              child: Container(
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF4A90E2), Color(0xFF2E5C8A)],
                  ),
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
            ),
          ),
        ),
      ),
      body: Obx(() {
        if (controller.isLoading.value) {
          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF4A90E2)),
                ),
                SizedBox(height: 16.h),
                Text(
                  'Chargement des données...',
                  style: TextStyle(color: Colors.white60, fontSize: 14.sp),
                ),
              ],
            ),
          );
        }

        return SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Padding(
            padding: EdgeInsets.all(20.w),
            children: [
              // En-tête avec icône
              _buildSectionHeader(
                icon: Icons.inventory_2_outlined,
                title: 'Détails du Container',
                subtitle: 'Informations sur la cargaison',
              ),
              SizedBox(height: 16.h),

              // Carte Container
              _ModernCard(
                child: Column(
                  children: [
                    _buildTextField(
                      label: 'ID Container',
                      controller: _containerCtrl,
                      onChanged: (v) => controller.containerId.value = v,
                      hint: "Ex: MSKU1234567",
                      icon: Icons.qr_code_2_rounded,
                      keyboardType: TextInputType.text,
                    ),
                    SizedBox(height: 20.h),
                    _buildDropdown(
                      label: 'Terminal de destination',
                      value: controller.selectedGateId.value?.toString(),
                      items: controller.terminals
                          .map((e) => e.id.toString())
                          .toList(),
                      display: (id) => controller.terminals
                          .firstWhere((t) => t.id.toString() == id)
                          .name,
                      onChanged: (v) => controller.setGate(int.parse(v!)),
                      icon: Icons.location_on_outlined,
                    ),
                  ],
                ),
              ),

              SizedBox(height: 32.h),

              // En-tête Chauffeur
              _buildSectionHeader(
                icon: Icons.local_shipping_outlined,
                title: 'Chauffeur & Camion',
                subtitle: 'Informations du transporteur',
              ),
              SizedBox(height: 16.h),

              // Carte Chauffeur
              _ModernCard(
                child: Column(
                  children: [
                    _buildTextField(
                      label: 'Plaque d\'immatriculation',
                      controller: _plateCtrl,
                      onChanged: (v) => controller.truckPlate.value = v,
                      hint: "Ex: 123456-16",
                      icon: Icons.directions_car_rounded,
                      keyboardType: TextInputType.text,
                    ),
                    SizedBox(height: 20.h),
                    _buildTextField(
                      label: 'Nom du Chauffeur',
                      controller: _nameCtrl,
                      onChanged: (v) => controller.driverName.value = v,
                      hint: "Nom complet",
                      icon: Icons.person_outline_rounded,
                      keyboardType: TextInputType.name,
                    ),
                    SizedBox(height: 20.h),
                    _buildTextField(
                      label: 'Téléphone',
                      controller: _phoneCtrl,
                      keyboardType: TextInputType.phone,
                      onChanged: (v) => controller.driverPhone.value = v,
                      hint: "Ex: 0555 123 456",
                      icon: Icons.phone_outlined,
                    ),
                  ],
                ),
              ),

              SizedBox(height: 32.h),

              // Bouton de validation
              _buildContinueButton(),

              SizedBox(height: 20.h),
            ],
          ),
        );
      }),
    );
  }

  Widget _buildSectionHeader({
    required IconData icon,
    required String title,
    required String subtitle,
  }) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                const Color(0xFF4A90E2).withOpacity(0.2),
                const Color(0xFF2E5C8A).withOpacity(0.1),
              ],
            ),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, color: const Color(0xFF4A90E2), size: 24.sp),
        ),
        SizedBox(width: 12.w),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.2,
                ),
              ),
              SizedBox(height: 2.h),
              Text(
                subtitle,
                style: TextStyle(
                  color: Colors.white60,
                  fontSize: 12.sp,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildTextField({
    required String label,
    required TextEditingController controller,
    required ValueChanged<String> onChanged,
    String? hint,
    IconData? icon,
    TextInputType? keyboardType,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.only(left: 4.w, bottom: 8.h),
          child: Text(
            label,
            style: TextStyle(
              color: Colors.white,
              fontSize: 13.sp,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        Container(
          decoration: BoxDecoration(
            color: const Color(0xFF0F2942),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.white.withOpacity(0.08), width: 1),
          ),
          child: TextField(
            controller: controller,
            onChanged: onChanged,
            keyboardType: keyboardType,
            style: TextStyle(color: Colors.white, fontSize: 14.sp),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: TextStyle(color: Colors.white30, fontSize: 14.sp),
              prefixIcon: icon != null
                  ? Icon(icon, color: const Color(0xFF4A90E2), size: 20.sp)
                  : null,
              filled: false,
              contentPadding: EdgeInsets.symmetric(
                horizontal: 16.w,
                vertical: 14.h,
              ),
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildDropdown({
    required String label,
    required String? value,
    required List<String> items,
    required ValueChanged<String?> onChanged,
    required String Function(String id) display,
    IconData? icon,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.only(left: 4.w, bottom: 8.h),
          child: Text(
            label,
            style: TextStyle(
              color: Colors.white,
              fontSize: 13.sp,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        Container(
          decoration: BoxDecoration(
            color: const Color(0xFF0F2942),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.white.withOpacity(0.08), width: 1),
          ),
          child: DropdownButtonFormField<String>(
            value: value,
            items: items
                .map(
                  (e) => DropdownMenuItem(
                    value: e,
                    child: Text(
                      display(e),
                      style: TextStyle(color: Colors.white, fontSize: 14.sp),
                    ),
                  ),
                )
                .toList(),
            onChanged: onChanged,
            icon: Icon(
              Icons.keyboard_arrow_down_rounded,
              color: const Color(0xFF4A90E2),
            ),
            decoration: InputDecoration(
              prefixIcon: icon != null
                  ? Icon(icon, color: const Color(0xFF4A90E2), size: 20.sp)
                  : Icon(
                      Icons.location_on_outlined,
                      color: const Color(0xFF4A90E2),
                      size: 20.sp,
                    ),
              filled: false,
              contentPadding: EdgeInsets.symmetric(
                horizontal: 16.w,
                vertical: 14.h,
              ),
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
            ),
            dropdownColor: const Color(0xFF0F2942),
            style: TextStyle(color: Colors.white, fontSize: 14.sp),
          ),
        ),
      ],
    );
  }

  Widget _buildContinueButton() {
    return Obx(() {
      final canContinue = controller.canGoToStep2();
      return Container(
        width: double.infinity,
        height: 56.h,
        decoration: BoxDecoration(
          gradient: canContinue
              ? const LinearGradient(
                  colors: [Color(0xFF4A90E2), Color(0xFF2E5C8A)],
                )
              : null,
          color: canContinue ? null : Colors.white.withOpacity(0.1),
          borderRadius: BorderRadius.circular(16),
          boxShadow: canContinue
              ? [
                  BoxShadow(
                    color: const Color(0xFF4A90E2).withOpacity(0.3),
                    blurRadius: 12,
                    offset: const Offset(0, 6),
                  ),
                ]
              : null,
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: canContinue
                ? () {
                    Get.to(() => const ReserveStep2Screen());
                  }
                : null,
            child: Container(
              alignment: Alignment.center,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Choisir un créneau horaire',
                    style: TextStyle(
                      fontSize: 16.sp,
                      fontWeight: FontWeight.w600,
                      color: canContinue ? Colors.white : Colors.white30,
                      letterSpacing: 0.5,
                    ),
                  ),
                  SizedBox(width: 8.w),
                  Icon(
                    Icons.arrow_forward_rounded,
                    color: canContinue ? Colors.white : Colors.white30,
                    size: 20.sp,
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    });
  }
}

class _ModernCard extends StatelessWidget {
  final Widget child;
  const _ModernCard({required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(24.w),
      decoration: BoxDecoration(
        color: const Color(0xFF152238),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.05), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: child,
    );
  }
}
