import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:listenlit/controllers/booking_controller.dart';
import 'package:listenlit/model/slot.dart';

class ReserveStep2Screen extends StatelessWidget {
  const ReserveStep2Screen({super.key});

  @override
  Widget build(BuildContext context) {
    final BookingController controller = Get.find<BookingController>();

    return Scaffold(
      backgroundColor: const Color(0xFF0B1F35),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0F2942),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            color: Colors.white,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Sélection du Créneau',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18.sp,
                fontWeight: FontWeight.w600,
              ),
            ),
            Text(
              'Étape 2 sur 2',
              style: TextStyle(
                color: Colors.white60,
                fontSize: 12.sp,
                fontWeight: FontWeight.w400,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: Colors.white70),
            onPressed: () => controller.loadAvailableSlots(),
            tooltip: 'Actualiser',
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(6),
          child: Container(
            height: 6.h,
            margin: EdgeInsets.symmetric(horizontal: 16.w),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF4A90E2), Color(0xFF2E5C8A)],
              ),
              borderRadius: BorderRadius.circular(3),
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          _InfoSummary(controller: controller),
          Expanded(
            child: Obx(() {
              if (controller.isLoading.value) {
                return _buildLoadingState();
              }

              if (controller.errorMessage.value != null &&
                  controller.timeSlots.isEmpty) {
                return _ErrorState(
                  message: controller.errorMessage.value!,
                  onRetry: () => controller.loadAvailableSlots(),
                );
              }

              if (controller.timeSlots.isEmpty) {
                return const _EmptyState();
              }

              return _buildSlotGrid(controller);
            }),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF4A90E2)),
          ),
          SizedBox(height: 16.h),
          Text(
            'Chargement des créneaux disponibles...',
            style: TextStyle(color: Colors.white60, fontSize: 14.sp),
          ),
        ],
      ),
    );
  }

  Widget _buildSlotGrid(BookingController controller) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Padding(
        padding: EdgeInsets.all(20.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // En-tête de section
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        const Color(0xFF4A90E2).withOpacity(0.2),
                        const Color(0xFF2E5C8A).withOpacity(0.1),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    Icons.access_time_rounded,
                    color: const Color(0xFF4A90E2),
                    size: 24.sp,
                  ),
                ),
                SizedBox(width: 12.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Créneaux Disponibles',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 0.2,
                        ),
                      ),
                      SizedBox(height: 2.h),
                      Text(
                        '${controller.timeSlots.where((s) => s.available).length} créneaux libres',
                        style: TextStyle(
                          color: Colors.white50,
                          fontSize: 12.sp,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 20.h),

            // Grille de créneaux
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 12.w,
                mainAxisSpacing: 12.h,
                childAspectRatio: 2.2,
              ),
              itemCount: controller.timeSlots.length,
              itemBuilder: (context, index) {
                final slot = controller.timeSlots[index];
                return _SlotCard(
                  slot: slot,
                  onTap: () =>
                      _handleConfirmDialog(Get.context!, controller, slot),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  void _handleConfirmDialog(
    BuildContext context,
    BookingController controller,
    Slot slot,
  ) {
    if (!slot.available) return;

    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: EdgeInsets.all(24.w),
          decoration: BoxDecoration(
            color: const Color(0xFF152238),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: Colors.white.withOpacity(0.1), width: 1),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 30,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Icône
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      const Color(0xFF4A90E2).withOpacity(0.2),
                      const Color(0xFF2E5C8A).withOpacity(0.1),
                    ],
                  ),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.event_available_rounded,
                  color: const Color(0xFF4A90E2),
                  size: 40.sp,
                ),
              ),
              SizedBox(height: 20.h),

              // Titre
              Text(
                'Confirmer la Réservation',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20.sp,
                  fontWeight: FontWeight.w700,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 12.h),

              // Détails
              Container(
                padding: EdgeInsets.all(16.w),
                decoration: BoxDecoration(
                  color: const Color(0xFF0F2942),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    _buildDetailRow(
                      Icons.access_time_rounded,
                      'Créneau',
                      slot.formattedTime,
                    ),
                    Divider(color: Colors.white.withOpacity(0.1), height: 20.h),
                    _buildDetailRow(
                      Icons.inventory_2_outlined,
                      'Container',
                      controller.containerId.value,
                    ),
                    Divider(color: Colors.white.withOpacity(0.1), height: 20.h),
                    _buildDetailRow(
                      Icons.directions_car_rounded,
                      'Plaque',
                      controller.truckPlate.value,
                    ),
                  ],
                ),
              ),
              SizedBox(height: 24.h),

              // Boutons
              Row(
                children: [
                  Expanded(
                    child: _buildDialogButton(
                      label: 'Annuler',
                      onTap: () => Navigator.pop(context),
                      isPrimary: false,
                    ),
                  ),
                  SizedBox(width: 12.w),
                  Expanded(
                    child: _buildDialogButton(
                      label: 'Confirmer',
                      onTap: () async {
                        Navigator.pop(context);
                        controller.selectedSlot.value = slot;
                        final success = await controller.confirmFinalBooking();
                        if (success) {
                          Get.offAllNamed('/home');
                        }
                      },
                      isPrimary: true,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(IconData icon, String label, String value) {
    return Row(
      children: [
        Icon(icon, color: const Color(0xFF4A90E2), size: 18.sp),
        SizedBox(width: 12.w),
        Text(
          label,
          style: TextStyle(color: Colors.white60, fontSize: 13.sp),
        ),
        const Spacer(),
        Text(
          value,
          style: TextStyle(
            color: Colors.white,
            fontSize: 14.sp,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  Widget _buildDialogButton({
    required String label,
    required VoidCallback onTap,
    required bool isPrimary,
  }) {
    return Container(
      height: 48.h,
      decoration: BoxDecoration(
        gradient: isPrimary
            ? const LinearGradient(
                colors: [Color(0xFF4A90E2), Color(0xFF2E5C8A)],
              )
            : null,
        color: isPrimary ? null : Colors.white.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        boxShadow: isPrimary
            ? [
                BoxShadow(
                  color: const Color(0xFF4A90E2).withOpacity(0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ]
            : null,
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onTap,
          child: Center(
            child: Text(
              label,
              style: TextStyle(
                fontSize: 15.sp,
                fontWeight: FontWeight.w600,
                color: Colors.white,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// --- WIDGETS DE STYLE ---

class _SlotCard extends StatelessWidget {
  final Slot slot;
  final VoidCallback onTap;

  const _SlotCard({required this.slot, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: slot.available ? onTap : null,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          decoration: BoxDecoration(
            gradient: slot.available
                ? LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [const Color(0xFF152238), const Color(0xFF0F2942)],
                  )
                : null,
            color: slot.available
                ? null
                : const Color(0xFF0F2942).withOpacity(0.3),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: slot.available
                  ? const Color(0xFF4A90E2).withOpacity(0.4)
                  : Colors.white.withOpacity(0.05),
              width: 1.5,
            ),
            boxShadow: slot.available
                ? [
                    BoxShadow(
                      color: const Color(0xFF4A90E2).withOpacity(0.15),
                      blurRadius: 8,
                      offset: const Offset(0, 4),
                    ),
                  ]
                : null,
          ),
          child: Stack(
            children: [
              // Badge de statut
              Positioned(
                top: 8.h,
                right: 8.w,
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                  decoration: BoxDecoration(
                    color: slot.available
                        ? const Color(0xFF10B981).withOpacity(0.2)
                        : const Color(0xFFEF4444).withOpacity(0.2),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: slot.available
                          ? const Color(0xFF10B981)
                          : const Color(0xFFEF4444),
                      width: 1,
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 6.w,
                        height: 6.w,
                        decoration: BoxDecoration(
                          color: slot.available
                              ? const Color(0xFF10B981)
                              : const Color(0xFFEF4444),
                          shape: BoxShape.circle,
                        ),
                      ),
                      SizedBox(width: 4.w),
                      Text(
                        slot.available ? 'Libre' : 'Complet',
                        style: TextStyle(
                          color: slot.available
                              ? const Color(0xFF10B981)
                              : const Color(0xFFEF4444),
                          fontSize: 9.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // Contenu principal
              Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.schedule_rounded,
                      color: slot.available
                          ? const Color(0xFF4A90E2)
                          : Colors.white24,
                      size: 28.sp,
                    ),
                    SizedBox(height: 8.h),
                    Text(
                      slot.formattedTime,
                      style: TextStyle(
                        color: slot.available ? Colors.white : Colors.white30,
                        fontWeight: FontWeight.w700,
                        fontSize: 15.sp,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _InfoSummary extends StatelessWidget {
  final BookingController controller;
  const _InfoSummary({required this.controller});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.fromLTRB(20.w, 20.h, 20.w, 0),
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [const Color(0xFF152238), const Color(0xFF0F2942)],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.1), width: 1),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Icon(
                Icons.info_outline_rounded,
                color: const Color(0xFF4A90E2),
                size: 20.sp,
              ),
              SizedBox(width: 8.w),
              Text(
                'Récapitulatif',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 13.sp,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          Divider(color: Colors.white.withOpacity(0.1), height: 20.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildInfoChip(
                Icons.inventory_2_outlined,
                controller.containerId.value,
              ),
              Container(
                width: 1,
                height: 20.h,
                color: Colors.white.withOpacity(0.1),
              ),
              _buildInfoChip(
                Icons.directions_car_rounded,
                controller.truckPlate.value,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildInfoChip(IconData icon, String text) {
    return Row(
      children: [
        Icon(icon, color: const Color(0xFF4A90E2), size: 16.sp),
        SizedBox(width: 6.w),
        Text(
          text,
          style: TextStyle(
            color: Colors.white,
            fontSize: 12.sp,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}

class _ErrorState extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const _ErrorState({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(32.w),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: const Color(0xFFEF4444).withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.error_outline_rounded,
                color: const Color(0xFFEF4444),
                size: 48.sp,
              ),
            ),
            SizedBox(height: 24.h),
            Text(
              'Une erreur est survenue',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18.sp,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 8.h),
            Text(
              message,
              style: TextStyle(color: Colors.white60, fontSize: 14.sp),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 24.h),
            ElevatedButton.icon(
              onPressed: onRetry,
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('Réessayer'),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF4A90E2),
                foregroundColor: Colors.white,
                padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 12.h),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(32.w),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    const Color(0xFF4A90E2).withOpacity(0.2),
                    const Color(0xFF2E5C8A).withOpacity(0.1),
                  ],
                ),
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.event_busy_rounded,
                color: const Color(0xFF4A90E2),
                size: 48.sp,
              ),
            ),
            SizedBox(height: 24.h),
            Text(
              'Aucun créneau disponible',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18.sp,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 8.h),
            Text(
              'Il n\'y a pas de créneaux disponibles\npour cette porte actuellement',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white50,
                fontSize: 14.sp,
                height: 1.4,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
