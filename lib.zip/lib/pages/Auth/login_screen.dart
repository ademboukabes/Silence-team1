// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:listenlit/controllers/auth_controller.dart';
import 'package:listenlit/general_widgets/primarybutton.dart';
import 'package:listenlit/general_widgets/passwordtextfield.dart';
import 'package:listenlit/utils/colors.dart';
import 'package:listenlit/pages/Auth/signup_screen.dart';
import 'package:listenlit/pages/landingScreen/landing_screen.dart';
import 'package:listenlit/pages/Auth/forgetpassword_screen.dart';

class LoginScreen extends StatelessWidget {
  LoginScreen({super.key});
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passController = TextEditingController();
  final AuthController authController = Get.find<AuthController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Column(
          children: [
            SizedBox(height: 70.h),
            Text(
              'APOS',
              style: TextStyle(
                fontSize: 28.sp,
                fontWeight: FontWeight.w900,
                color: const Color(0xFF1C3D5A),
                fontFamily: 'Inter',
              ),
            ),
            SizedBox(height: 16.h),
            Container(
              margin: EdgeInsets.symmetric(horizontal: 22.w),
              padding: EdgeInsets.symmetric(horizontal: 18.w, vertical: 24.h),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(26.r),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    const Color(0xFFBFE9FF).withOpacity(0.9),
                    const Color(0xFF6EA9CF).withOpacity(0.9),
                  ],
                ),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF1C4F72).withOpacity(0.35),
                    blurRadius: 18,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Text(
                    'Log in',
                    style: TextStyle(
                      fontSize: 20.sp,
                      fontWeight: FontWeight.w800,
                      color: const Color(0xFF1C3D5A),
                    ),
                  ),
                  SizedBox(height: 16.h),
                  _softField(
                    hint: 'email',
                    controller: emailController,
                  ),
                  SizedBox(height: 12.h),
                  PasswordTextField(
                    hintText: 'Password',
                    controller: passController,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.r),
                    ),
                    width: double.infinity,
                    height: 46.h,
                  ),
                  SizedBox(height: 14.h),
                  PrimaryButton(
                    onTap: () {
                      final email = emailController.text.trim();
                      final pass = passController.text;
                      if (email.isEmpty || pass.isEmpty) {
                        authController.loginError.value =
                            'Email and password required.';
                        return;
                      }
                      authController.login(email: email, password: pass);
                    },
                    borderRadius: 18.r,
                    fontSize: 14.sp,
                    height: 42.h,
                    width: 220.w,
                    text: 'Log in',
                    textColor: AppColor.kWhiteColor,
                    bgColor: const Color(0xFF2F80ED),
                  ),
                  SizedBox(height: 10.h),
                  TextButton(
                    onPressed: () {
                      Get.to(() => ForgetPasswordScreen());
                    },
                    child: Text(
                      'Forgot password?',
                      style: TextStyle(
                        color: const Color(0xFF1C3D5A),
                        fontSize: 11.sp,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  SizedBox(height: 6.h),
                  OutlinedButton(
                    onPressed: () {
                      Get.to(() => SignUpScreen());
                    },
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Color(0xFF2F80ED)),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18),
                      ),
                    ),
                    child: Text(
                      'Create account',
                      style: TextStyle(
                        color: const Color(0xFF2F80ED),
                        fontSize: 12.sp,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  SizedBox(height: 14.h),
                  _quickAccounts(),
                  Obx(() {
                    final err = authController.loginError.value;
                    if (err == null || err.isEmpty) {
                      return const SizedBox.shrink();
                    }
                    return Padding(
                      padding: EdgeInsets.only(top: 8.h),
                      child: Text(
                        err,
                        style: TextStyle(
                          color: Colors.redAccent,
                          fontSize: 12.sp,
                          fontFamily: 'Inter',
                        ),
                      ),
                    );
                  }),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _softField({
    required String hint,
    required TextEditingController controller,
  }) {
    return TextField(
      controller: controller,
      style: const TextStyle(color: Color(0xFF1C3D5A)),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(
          color: Color(0xFF3C5E78),
          fontWeight: FontWeight.w600,
        ),
        filled: true,
        fillColor: Colors.white.withOpacity(0.65),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }

  Widget _quickAccounts() {
    return Column(
      children: [
        Text(
          'Quick access',
          style: TextStyle(
            color: const Color(0xFF1C3D5A),
            fontSize: 12.sp,
            fontWeight: FontWeight.w700,
          ),
        ),
        SizedBox(height: 8.h),
        Wrap(
          spacing: 8.w,
          runSpacing: 8.h,
          alignment: WrapAlignment.center,
          children: [
            _quickButton('Demo Transitaire'),
            _quickButton('Demo Agent'),
          ],
        ),
      ],
    );
  }

  Widget _quickButton(String label) {
    return OutlinedButton(
      onPressed: () {
        Get.off(() => const LandingScreen());
      },
      style: OutlinedButton.styleFrom(
        side: const BorderSide(color: Color(0xFF1C4F72)),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
        ),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: const Color(0xFF1C4F72),
          fontSize: 11.sp,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}
