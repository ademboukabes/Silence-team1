// lib/pages/profile/profile_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:listenlit/controllers/auth_controller.dart';

import 'widgets/info_tile.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = Get.find<AuthController>();
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            'Profil',
            style: TextStyle(
              fontSize: 20.sp,
              fontWeight: FontWeight.w700,
              color: Colors.white,
              fontFamily: 'Inter',
            ),
          ),
          SizedBox(height: 12.h),
          Obx(() {
            final user = auth.user.value;
            final name = user?['name']?.toString() ?? '';
            final id = user?['id']?.toString() ?? '';
            final company =
                user?['company']?.toString() ?? user?['carrier']?.toString() ?? '';
            final carrierId = user?['carrierId']?.toString() ?? '';
            return _Card(
              child: Column(
                children: [
                  InfoTile(label: 'Nom', value: name.isEmpty ? '-' : name),
                  InfoTile(label: 'ID', value: id.isEmpty ? '-' : id),
                  InfoTile(
                    label: 'Compagnie',
                    value: company.isEmpty ? '-' : company,
                  ),
                  InfoTile(
                    label: 'Carrier ID',
                    value: carrierId.isEmpty ? '-' : carrierId,
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }
}

class _Card extends StatelessWidget {
  final Widget child;

  const _Card({required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF5D7C95),
            Color(0xFF274B66),
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: child,
    );
  }
}
