import 'package:get/get.dart';
import 'package:listenlit/model/slot.dart';
import 'package:listenlit/data/providers/booking_provider.dart';

class BookingController extends GetxController {
  // --- Dépendances ---
  final BookingProvider _bookingProvider = Get.find<BookingProvider>();

  // --- ÉTAPE 1 : Informations (Saisie Manuelle) ---
  var selectedGateId = Rxn<int>();
  var containerId = "".obs;
  var truckPlate = "".obs;
  var driverPhone = "".obs;
  var driverName = "".obs;
  var movementType = "IMPORT".obs;

  // --- Données pour les listes ---
  var terminals = <dynamic>[].obs; // Contiendra les Gates récupérées via API
  var timeSlots = <Slot>[].obs;
  var selectedSlot = Rxn<Slot>();

  // --- États de l'interface (UI State) ---
  var isLoading = false.obs;
  var loadingSlots =
      false.obs; // Utilisé par l'écran Step 1 pour le chargement initial
  var isSubmitting = false.obs;
  var errorMessage = Rxn<String>();
  var error = Rxn<String>(); // Alias pour la compatibilité avec votre UI

  @override
  void onInit() {
    super.onInit();
    loadInit(); // Charge les terminaux dès le lancement du contrôleur
  }

  /// CHARGEMENT INITIAL : Récupère les portes (Gates) pour le formulaire
  /// Puisque les camions sont contactés hors-app, on ne charge que les terminaux.
  Future<void> loadInit() async {
    try {
      loadingSlots.value = true;
      error.value = null;

      // Appel de l'API pour obtenir les portes disponibles
      // Note: Assurez-vous que getGates() existe dans votre BookingProvider
      final response = await _bookingProvider.getGates();
      terminals.value = response;
    } catch (e) {
      error.value = "Erreur lors de la récupération des terminaux.";
    } finally {
      loadingSlots.value = false;
    }
  }

  /// Appelé quand le transitaire choisit un terminal/gate
  void setGate(int id) {
    selectedGateId.value = id;
    loadAvailableSlots(); // Charge les créneaux dès que la porte change
  }

  /// Charge les créneaux (Slots) pour le terminal sélectionné
  Future<void> loadAvailableSlots() async {
    if (selectedGateId.value == null) return;

    try {
      isLoading.value = true;
      errorMessage.value = null;

      final List<dynamic> response = await _bookingProvider.getTimeSlots(
        gateId: selectedGateId.value,
      );

      // Conversion JSON en objets Slot
      timeSlots.value = response.map((json) => Slot.fromJson(json)).toList();

      if (timeSlots.isEmpty) {
        errorMessage.value = "Aucun créneau disponible pour ce terminal.";
      }
    } catch (e) {
      errorMessage.value =
          "Erreur de connexion : Impossible de récupérer les horaires.";
    } finally {
      isLoading.value = false;
    }
  }

  /// Validation de l'Étape 1 avant de passer au calendrier
  bool canGoToStep2() {
    if (containerId.value.isEmpty ||
        truckPlate.value.isEmpty ||
        driverPhone.value.isEmpty ||
        selectedGateId.value == null) {
      Get.snackbar(
        "Champs manquants",
        "Veuillez remplir les informations du chauffeur contacté et du terminal.",
      );
      return false;
    }
    return true;
  }

  /// Envoi final de la réservation au port
  Future<bool> confirmFinalBooking() async {
    if (selectedSlot.value == null) {
      errorMessage.value = "Veuillez sélectionner un créneau horaire.";
      return false;
    }

    try {
      isSubmitting.value = true;
      errorMessage.value = null;

      // Création de la réservation avec les données saisies manuellement
      final result = await _bookingProvider.create(
        gateId: selectedGateId.value!,
        timeSlotId: int.parse(selectedSlot.value!.id),
        truckId: 0, // Pas de camion pré-enregistré
        carrierId: 0, // Sera remplacé par l'ID de l'utilisateur connecté
        driverName: driverName.value,
        driverEmail: "",
        driverPhone: driverPhone.value,
        driverMatricule: truckPlate.value,
        merchandiseDescription: "Container: ${containerId.value}",
        notes: "Type: ${movementType.value}",
      );

      Get.snackbar("Succès", "Le créneau a été réservé pour votre chauffeur !");
      return true;
    } catch (e) {
      errorMessage.value =
          "Échec de la réservation. Le créneau est peut-être complet.";
      return false;
    } finally {
      isSubmitting.value = false;
    }
  }
}
